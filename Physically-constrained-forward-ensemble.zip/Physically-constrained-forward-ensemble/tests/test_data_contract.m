function tests = test_data_contract
tests = functiontests(localfunctions);
end

function testLikelihoodWindowIsExplicitAndComplete(testCase)
packageRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(packageRoot, 'model'));

csvPath = fullfile(packageRoot, 'data', 'cs_fig2_data.csv');
analysisWindow = [441.524558823529, 438.590];
data = cs_load_data(csvPath, analysisWindow);

verifyEqual(testCase, data.counts.total_d34S, 32);
verifyEqual(testCase, data.counts.included_d34S, 32);
verifyEqual(testCase, data.counts.excluded_d34S, 0);
verifyEqual(testCase, nnz(data.obs.dataset == "TP"), 32);
verifyEqual(testCase, nnz(data.obs.dataset == "DJG"), 0);
verifyEqual(testCase, data.counts.display_d34S, 52);
verifyEqual(testCase, nnz(data.display.d34S.dataset == "TP"), 32);
verifyEqual(testCase, nnz(data.display.d34S.dataset == "DJG"), 20);
verifyEqual(testCase, height(unique(data.obs(:, {'age_ma', 'd34S'}))), ...
    height(data.obs), 'Likelihood observations must not be duplicated.');
verifyTrue(testCase, all(data.obs.age_ma <= analysisWindow(1)));
verifyTrue(testCase, all(data.obs.age_ma >= analysisWindow(2)));
verifyTrue(testCase, all(isfinite(data.obs.d34S)));
verifyTrue(testCase, all(isfinite(data.obs.sigma)));
verifyLessThanOrEqual(testCase, min(data.forcing.age_ma), 438.0);
verifyGreaterThanOrEqual(testCase, max(data.forcing.age_ma), analysisWindow(1));
end
