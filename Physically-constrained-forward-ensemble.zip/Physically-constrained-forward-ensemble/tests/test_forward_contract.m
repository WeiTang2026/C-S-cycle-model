function tests = test_forward_contract
tests = functiontests(localfunctions);
end

function testBothVariantsAreFiniteAndSulfateBounded(testCase)
packageRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(packageRoot, 'model'));
for variant = {'linear', 'nonlinear'}
    cfg = cs_default_config('smoke', variant{1});
    data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
        cfg.analysis_window);
    out = cs_forward(cfg.reference_theta, data, cfg, 'full');
    verifyTrue(testCase, out.ok, out.message);
    verifyEqual(testCase, numel(out.obs_pred), data.counts.included_d34S);
    verifyTrue(testCase, all(isfinite(out.d34S)));
    verifyTrue(testCase, all(isfinite(out.S_mM)));
    verifyGreaterThanOrEqual(testCase, min(out.S_mM), 1 - 1e-6);
    verifyLessThanOrEqual(testCase, max(out.S_mM), 3 + 1e-6);
    verifyTrue(testCase, all(out.Corg_18 > 0));
    verifyTrue(testCase, all(out.Py_18 > 0));
    verifyTrue(testCase, all(out.Gyp_18 > 0));
    verifyEqual(testCase, out.B_PYR0_18 + out.B_GYP0_18, ...
        cfg.reference_theta(cfg.index.W_PYR) ...
        + cfg.reference_theta(cfg.index.W_GYP), 'AbsTol', 1e-12);
end
end

function testEtaZeroNestsTheLiteratureLinearModel(testCase)
packageRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(packageRoot, 'model'));
linearCfg = cs_default_config('smoke', 'linear');
nonlinearCfg = cs_default_config('smoke', 'nonlinear');
data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
    linearCfg.analysis_window);
thetaLinear = linearCfg.reference_theta;
thetaNonlinear = [thetaLinear, 0];
outLinear = cs_forward(thetaLinear, data, linearCfg, 'full');
outNonlinear = cs_forward(thetaNonlinear, data, nonlinearCfg, 'full');
verifyTrue(testCase, outLinear.ok, outLinear.message);
verifyTrue(testCase, outNonlinear.ok, outNonlinear.message);
verifyEqual(testCase, outLinear.d34S, outNonlinear.d34S, 'AbsTol', 1e-10);
verifyEqual(testCase, outLinear.S_mM, outNonlinear.S_mM, 'AbsTol', 1e-10);
verifyEqual(testCase, outLinear.Py_18, outNonlinear.Py_18, 'AbsTol', 1e-10);
end

function testBCIsPriorPropagatedOnly(testCase)
packageRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(packageRoot, 'model'));
cfg = cs_default_config('smoke', 'linear');
data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
    cfg.analysis_window);
theta1 = cfg.reference_theta;
theta2 = theta1;
theta2(cfg.index.B_C) = 22;
out1 = cs_forward(theta1, data, cfg, 'full');
out2 = cs_forward(theta2, data, cfg, 'full');
verifyEqual(testCase, out1.d34S, out2.d34S, 'AbsTol', 0);
verifyEqual(testCase, out1.S_mM, out2.S_mM, 'AbsTol', 0);
verifyNotEqual(testCase, out1.carbon_residual_18, out2.carbon_residual_18);
end

function testDelta13CInputOverrideChangesOnlySpecifiedForcing(testCase)
packageRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(packageRoot, 'model'));
cfg = cs_default_config('smoke', 'linear');
data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
    cfg.analysis_window);
theta = cfg.reference_theta;
effectiveInput = (theta(cfg.index.W_G) .* cfg.delta_G ...
    + theta(cfg.index.W_C) .* cfg.delta_C) ...
    ./ (theta(cfg.index.W_G) + theta(cfg.index.W_C));

central = cs_forward(theta, data, cfg, 'full');
sameForcing = cs_forward(theta, data, cfg, 'full', effectiveInput);
minus8 = cs_forward(theta, data, cfg, 'full', -8.0);
minus5 = cs_forward(theta, data, cfg, 'full', -5.0);

verifyTrue(testCase, central.ok, central.message);
verifyTrue(testCase, sameForcing.ok, sameForcing.message);
verifyTrue(testCase, minus8.ok, minus8.message);
verifyTrue(testCase, minus5.ok, minus5.message);
verifyEqual(testCase, central.delta_in_effective, effectiveInput, ...
    'AbsTol', 1e-12);
verifyEqual(testCase, central.d34S, sameForcing.d34S, 'AbsTol', 1e-10);
verifyEqual(testCase, central.Corg_18, sameForcing.Corg_18, 'AbsTol', 1e-10);
verifyEqual(testCase, minus8.delta_in_effective, -8.0, 'AbsTol', 0);
verifyEqual(testCase, minus5.delta_in_effective, -5.0, 'AbsTol', 0);
verifyNotEqual(testCase, minus8.Corg_18, minus5.Corg_18);
end
