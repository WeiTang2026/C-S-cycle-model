function tests = test_screen_contract
tests = functiontests(localfunctions);
end

function testForwardScreenIsDeterministicAndRanksTPOnly(testCase)
packageRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(packageRoot, 'model'));
for variant = {'linear', 'nonlinear'}
    cfg = cs_default_config('production', variant{1});
    data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
        cfg.analysis_window);
    b1 = cs_screen_block(data, cfg, 91, 40);
    b2 = cs_screen_block(data, cfg, 91, 40);
    verifyEqual(testCase, b1.theta, b2.theta, 'AbsTol', 0);
    verifyEqual(testCase, b1.metrics, b2.metrics, 'AbsTol', 0);
    verifyGreaterThan(testCase, b1.n_valid, 0);
    verifyEqual(testCase, size(b1.theta, 2), numel(cfg.lower));
    verifyEqual(testCase, size(b1.metrics, 2), numel(b1.metric_names));
    verifyTrue(testCase, ismember('TP_RMSE_permil', b1.metric_names));
    verifyEqual(testCase, unique(b1.theta(:, cfg.index.DeltaC)), 27.0, ...
        'AbsTol', 0);
    verifyTrue(testCase, all(b1.metrics(:, 8) >= 1 - 1e-6));
    verifyTrue(testCase, all(b1.metrics(:, 9) <= 3 + 1e-6));
end
end
