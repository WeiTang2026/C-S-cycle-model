function cs_make_fig2(data, cfg, bands, resultsDir)
%CS_MAKE_FIG2 Render the manuscript-style four-panel result.

if ~isfolder(resultsDir)
    mkdir(resultsDir);
end

colors = struct();
colors.forcing = [0, 114, 178] ./ 255;
colors.tp = [0, 158, 115] ./ 255;
colors.djg = [204, 121, 167] ./ 255;
colors.model = [213, 94, 0] ./ 255;
colors.modelBand = [248, 199, 190] ./ 255;
colors.corg = [0, 114, 178] ./ 255;
colors.corgBand = [190, 215, 235] ./ 255;
colors.py = [166, 105, 0] ./ 255;
colors.pyBand = [245, 224, 180] ./ 255;
colors.o2 = [213, 94, 0] ./ 255;
colors.o2Band = [250, 205, 195] ./ 255;

fig = figure('Visible', 'off', 'Color', 'w', 'Position', [40, 40, 1500, 1120]);
layout = tiledlayout(fig, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% Panel A: forcing and local carbon-isotope observations.
axA = nexttile(layout, 1); hold(axA, 'on');
forcingGrid = cfg.plot_grid;
forcingLine = interp1(data.forcing.age_ma, data.forcing.d13C, ...
    forcingGrid, 'pchip');
pA1 = plot(axA, forcingGrid, forcingLine, '-', 'Color', colors.forcing, ...
    'LineWidth', 2.2);
displayRaw = data.display.forcing_display;
scatter(axA, displayRaw.age_ma, displayRaw.d13C, 26, 'o', ...
    'MarkerFaceColor', lighten(colors.forcing, 0.35), ...
    'MarkerEdgeColor', 'w', 'LineWidth', 0.35);
tpC = data.display.TP;
djgC = data.display.DJG;
pA2 = scatter(axA, tpC.age_ma, tpC.d13C, 38, 's', ...
    'MarkerFaceColor', lighten(colors.tp, 0.45), ...
    'MarkerEdgeColor', 'w', 'LineWidth', 0.5);
pA3 = scatter(axA, djgC.age_ma, djgC.d13C, 38, 'd', ...
    'MarkerFaceColor', lighten(colors.djg, 0.35), ...
    'MarkerEdgeColor', 'w', 'LineWidth', 0.5);
format_age_axis(axA, cfg, true);
ylabel(axA, 'δ¹³C forcing and observations (‰)', 'Interpreter', 'none');
ylim(axA, [-2.5, 6.5]);
legend(axA, [pA1, pA2, pA3], ...
    {'Composite \delta^{13}C forcing', 'TP', 'DJG'}, ...
    'Location', 'northwest', 'Box', 'off');
panel_label(axA, 'A');

% Panel B: sulfur-isotope fit and delta13C_in sensitivity envelope.
axB = nexttile(layout, 2); hold(axB, 'on');
q = bands.d34S_latent_q;
fill_band(axB, bands.age_ma, q(:, 1), q(:, 3), colors.modelBand, 0.70);
pB1 = plot(axB, bands.age_ma, bands.d34S_latent_q(:, 2), '-', ...
    'Color', colors.model, 'LineWidth', 3.0);
displayS = data.display.d34S;
tpMask = displayS.dataset == "TP";
djgMask = displayS.dataset == "DJG";
pB2 = scatter(axB, displayS.age_ma(tpMask), displayS.d34S(tpMask), 45, 'o', ...
    'MarkerFaceColor', lighten(colors.tp, 0.45), ...
    'MarkerEdgeColor', 'w', 'LineWidth', 0.6);
pB3 = scatter(axB, displayS.age_ma(djgMask), displayS.d34S(djgMask), 45, 'd', ...
    'MarkerFaceColor', lighten(colors.djg, 0.35), ...
    'MarkerEdgeColor', 'w', 'LineWidth', 0.6);
format_age_axis(axB, cfg, true);
ylabel(axB, 'Seawater δ³⁴S (‰)', 'Interpreter', 'none');
ylim(axB, [10, 40]);
isScreen = isfield(cfg, 'result_type') && strcmp(cfg.result_type, 'forward_screen');
if strcmp(cfg.variant, 'linear') && isScreen
    modelLabel = 'Best literature-linear forward case';
elseif strcmp(cfg.variant, 'nonlinear') && isScreen
    modelLabel = 'Best free-\eta forward case';
elseif strcmp(cfg.variant, 'linear')
    modelLabel = 'Literature-linear model';
else
    modelLabel = 'Free-\eta sensitivity model';
end
legend(axB, [pB1, pB2, pB3], {modelLabel, 'TP', 'DJG'}, ...
    'Location', 'northwest', 'Orientation', 'horizontal', 'Box', 'off');
if isScreen
    intervalLabel = '\delta^{13}C_{in} sensitivity: -8 to -5‰';
else
    intervalLabel = '95% model interval';
end
text(axB, 440.05, 31.5, sprintf(['%s\n', ...
    'SO_4: %.2f-%.2f mM'], intervalLabel, min(bands.S_mM_q(:, 2)), ...
    max(bands.S_mM_q(:, 2))), ...
    'FontSize', 10, 'Color', [0.35, 0.25, 0.25]);
panel_label(axB, 'B');

% Panel C: carbon and pyrite burial rates.
axC = nexttile(layout, 3); hold(axC, 'on');
fill_band(axC, bands.age_ma, bands.Corg_q(:, 1), bands.Corg_q(:, 3), ...
    colors.corgBand, 0.65);
fill_band(axC, bands.age_ma, bands.Py_q(:, 1), bands.Py_q(:, 3), ...
    colors.pyBand, 0.65);
pC1 = plot(axC, bands.age_ma, bands.Corg_q(:, 2), '--', ...
    'Color', colors.corg, 'LineWidth', 2.6);
pC2 = plot(axC, bands.age_ma, bands.Py_q(:, 2), '--', ...
    'Color', colors.py, 'LineWidth', 2.6);
format_age_axis(axC, cfg, true);
ylabel(axC, 'Flux (\times10^{18} mol Myr^{-1})');
legend(axC, [pC1, pC2], {'C_{org} burial rate', 'Pyrite burial rate'}, ...
    'Location', 'northwest', 'Box', 'off');
fluxMin = min([bands.Corg_q(:, 1); bands.Py_q(:, 1)]);
fluxMax = max([bands.Corg_q(:, 3); bands.Py_q(:, 3)]);
ylim(axC, [min(2, floor(fluxMin)), max(16, ceil(fluxMax))]);
panel_label(axC, 'C');

% Panel D: oxygen-production rate.
axD = nexttile(layout, 4); hold(axD, 'on');
fill_band(axD, bands.age_ma, bands.O2_q(:, 1), bands.O2_q(:, 3), ...
    colors.o2Band, 0.65);
plot(axD, bands.age_ma, bands.O2_q(:, 2), '--', ...
    'Color', colors.o2, 'LineWidth', 2.8);
format_age_axis(axD, cfg, true);
ylabel(axD, 'O_2 production (\times10^{18} mol Myr^{-1})');
o2Min = min(bands.O2_q(:, 1));
o2Max = max(bands.O2_q(:, 3));
ylim(axD, [min(5, floor(o2Min)), max(35, ceil(o2Max))]);
panel_label(axD, 'D');

set(findall(fig, '-property', 'FontName'), 'FontName', 'Arial');
set(findall(fig, '-property', 'FontSize'), 'FontSize', 11);

exportgraphics(fig, fullfile(resultsDir, 'Fig2_CS_inversion.png'), ...
    'Resolution', 300, 'BackgroundColor', 'white');
exportgraphics(fig, fullfile(resultsDir, 'Fig2_CS_inversion.tif'), ...
    'Resolution', 600, 'BackgroundColor', 'white');
exportgraphics(fig, fullfile(resultsDir, 'Fig2_CS_inversion.pdf'), ...
    'ContentType', 'vector', 'BackgroundColor', 'white');
close(fig);
end

function format_age_axis(ax, cfg, showXLabel)
set(ax, 'XDir', 'reverse', 'Box', 'on', 'LineWidth', 1.0, ...
    'TickDir', 'out', 'Layer', 'top', 'Color', 'w');
xlim(ax, [cfg.plot_window(2), cfg.plot_window(1)]);
ageTicks = 438:1:floor(cfg.plot_window(1));
if cfg.plot_window(1) - floor(cfg.plot_window(1)) >= 0.45
    ageTicks(end + 1) = floor(cfg.plot_window(1)) + 0.5;
end
xticks(ax, ageTicks);
grid(ax, 'off');
if showXLabel
    xlabel(ax, 'Age (Ma)');
else
    ax.XTickLabel = [];
end
end

function fill_band(ax, x, low, high, color, alpha)
fill(ax, [x; flipud(x)], [low; flipud(high)], color, ...
    'EdgeColor', 'none', 'FaceAlpha', alpha, 'HandleVisibility', 'off');
end

function panel_label(ax, label)
text(ax, 0.965, 0.955, label, 'Units', 'normalized', ...
    'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
    'FontSize', 18, 'FontWeight', 'bold');
end

function out = lighten(color, fraction)
out = color + (1 - color) .* fraction;
end
