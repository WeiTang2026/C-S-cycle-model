function cs_make_screen_gif(data, cfg, theta, metrics, globalIndex, ...
    metricIndex, bands, bestMetrics, gifPath)
%CS_MAKE_SCREEN_GIF Animate best-so-far forward screening states.

if isfile(gifPath), delete(gifPath); end
[globalIndex, order] = sort(globalIndex);
theta = theta(order, :);
metrics = metrics(order, :);
n = size(theta, 1);
frameEnds = unique(round(linspace(max(1, ceil(n ./ cfg.gif.n_frames)), ...
    n, cfg.gif.n_frames)));
tmpPng = [gifPath, '.frame.png'];
cleanup = onCleanup(@() cleanup_temp(tmpPng));

for f = 1:numel(frameEnds)
    last = frameEnds(f);
    [~, bestLocal] = min(metrics(1:last, metricIndex.four_panel_score));
    out = cs_forward(theta(bestLocal, :), data, cfg, 'full');
    fig = figure('Visible', 'off', 'Color', 'w', 'Position', [50, 50, 1000, 650]);
    ax = axes(fig); hold(ax, 'on');
    if f == numel(frameEnds)
        q = bands.d34S_latent_q;
        fill(ax, [bands.age_ma; flipud(bands.age_ma)], ...
            [q(:, 1); flipud(q(:, 3))], [0.97, 0.78, 0.75], ...
            'EdgeColor', 'none', 'FaceAlpha', 0.7);
        modelAge = bands.age_ma;
        modelD34S = q(:, 2);
        frameRMSE = bestMetrics(metricIndex.TP_RMSE_permil);
        framePeak = bestMetrics(metricIndex.event_peak_permil);
    else
        modelAge = out.age_ma;
        modelD34S = out.d34S;
        frameRMSE = metrics(bestLocal, metricIndex.TP_RMSE_permil);
        framePeak = metrics(bestLocal, metricIndex.event_peak_permil);
    end
    plot(ax, modelAge, modelD34S, '-', 'Color', [0.84, 0.37, 0.0], ...
        'LineWidth', 3.0);
    displayS = data.display.d34S;
    tp = displayS.dataset == "TP";
    djg = displayS.dataset == "DJG";
    scatter(ax, displayS.age_ma(tp), displayS.d34S(tp), 48, 'o', ...
        'MarkerFaceColor', [0.45, 0.82, 0.66], 'MarkerEdgeColor', 'w');
    scatter(ax, displayS.age_ma(djg), displayS.d34S(djg), 48, 'd', ...
        'MarkerFaceColor', [0.83, 0.66, 0.79], 'MarkerEdgeColor', 'w');
    set(ax, 'XDir', 'reverse', 'Box', 'on', 'LineWidth', 1.1, ...
        'FontName', 'Arial', 'FontSize', 13, 'TickDir', 'out');
    xlim(ax, [cfg.plot_window(2), cfg.plot_window(1)]);
    ylim(ax, [10, 40]);
    xlabel(ax, 'Age (Ma)');
    ylabel(ax, 'Seawater \delta^{34}S (‰)');
    title(ax, sprintf(['%s forward screen: %d evaluated | TP RMSE %.2f‰ | ', ...
        'peak %.2f‰'], cfg.variant, globalIndex(last), ...
        frameRMSE, framePeak), ...
        'FontWeight', 'normal');
    exportgraphics(fig, tmpPng, 'Resolution', 110, 'BackgroundColor', 'white');
    close(fig);
    rgb = imread(tmpPng);
    [indexed, map] = rgb2ind(rgb, 256);
    if f == 1
        imwrite(indexed, map, gifPath, 'gif', 'LoopCount', Inf, ...
            'DelayTime', 0.18);
    else
        imwrite(indexed, map, gifPath, 'gif', 'WriteMode', 'append', ...
            'DelayTime', 0.18);
    end
end
clear cleanup;
end

function cleanup_temp(path)
if isfile(path), delete(path); end
end
