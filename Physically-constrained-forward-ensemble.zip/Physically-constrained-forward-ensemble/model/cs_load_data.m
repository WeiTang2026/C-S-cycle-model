function data = cs_load_data(csvPath, analysisWindow)
%CS_LOAD_DATA Read the normalized Fig. 2 data and apply an explicit window.

arguments
    csvPath (1,:) char
    analysisWindow (1,2) double {mustBeFinite}
end

if analysisWindow(1) <= analysisWindow(2)
    error('cs:InvalidWindow', 'analysisWindow must be [older_age, younger_age].');
end
if ~isfile(csvPath)
    error('cs:MissingData', 'Normalized input CSV does not exist: %s', csvPath);
end

T = readtable(csvPath, 'TextType', 'string', 'VariableNamingRule', 'preserve');
required = ["dataset", "variable", "age_ma", "value", ...
    "use_in_likelihood", "sigma_assumption"];
if ~all(ismember(required, string(T.Properties.VariableNames)))
    error('cs:BadDataContract', 'Normalized CSV is missing required columns.');
end

forcingMask = T.dataset == "forcing_model" & T.variable == "d13C";
forcingAge = T.age_ma(forcingMask);
forcingValue = T.value(forcingMask);
validForcing = isfinite(forcingAge) & isfinite(forcingValue);
[forcingAge, ia] = unique(forcingAge(validForcing), 'stable');
forcingValue = forcingValue(validForcing);
forcingValue = forcingValue(ia);
[forcingAge, order] = sort(forcingAge, 'ascend');
forcingValue = forcingValue(order);

if numel(forcingAge) < 4 || any(diff(forcingAge) <= 0)
    error('cs:BadForcing', 'Forcing ages must contain at least four unique points.');
end
if forcingAge(1) > analysisWindow(2) || forcingAge(end) < analysisWindow(1)
    error('cs:ForcingCoverage', 'Forcing does not cover the analysis window.');
end

% The inversion is explicitly calibrated to TP only. DJG remains a plotted
% external comparison and never contributes to the likelihood.
allDisplayMask = T.variable == "d34S" & T.use_in_likelihood == 1 ...
    & isfinite(T.age_ma) & isfinite(T.value);
likeMask = allDisplayMask & T.dataset == "TP";
total = nnz(likeMask);
inWindow = T.age_ma <= analysisWindow(1) & T.age_ma >= analysisWindow(2);
include = likeMask & inWindow & isfinite(T.age_ma) & isfinite(T.value) ...
    & isfinite(T.sigma_assumption) & T.sigma_assumption > 0;

data.source_csv = csvPath;
data.analysis_window = analysisWindow;
data.forcing = table(forcingAge, forcingValue, ...
    'VariableNames', {'age_ma', 'd13C'});
data.obs = table(T.dataset(include), T.age_ma(include), T.value(include), ...
    T.sigma_assumption(include), ...
    'VariableNames', {'dataset', 'age_ma', 'd34S', 'sigma'});
data.excluded = table(T.dataset(likeMask & ~include), T.age_ma(likeMask & ~include), ...
    T.value(likeMask & ~include), ...
    'VariableNames', {'dataset', 'age_ma', 'd34S'});
data.counts = struct( ...
    'total_d34S', total, ...
    'included_d34S', height(data.obs), ...
    'excluded_d34S', height(data.excluded), ...
    'display_d34S', nnz(allDisplayMask));

data.display.d34S = table(T.dataset(allDisplayMask), T.age_ma(allDisplayMask), ...
    T.value(allDisplayMask), ...
    'VariableNames', {'dataset', 'age_ma', 'd34S'});

displaySets = ["forcing_display", "TP", "DJG"];
for i = 1:numel(displaySets)
    key = matlab.lang.makeValidName(char(displaySets(i)));
    mask = T.dataset == displaySets(i) & T.variable == "d13C" ...
        & isfinite(T.age_ma) & isfinite(T.value);
    data.display.(key) = table(T.age_ma(mask), T.value(mask), ...
        'VariableNames', {'age_ma', 'd13C'});
end
end
