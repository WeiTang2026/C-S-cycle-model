function summary = cs_aggregate_screen(packageRoot, variant, expectedBlocks)
%CS_AGGREGATE_SCREEN Rank a forward ensemble and export Fig.2 products.

arguments
    packageRoot (1,:) char
    variant (1,:) char {mustBeMember(variant, {'linear', 'nonlinear'})}
    expectedBlocks (1,1) double {mustBeInteger, mustBePositive}
end

addpath(fullfile(packageRoot, 'model'));
cfg = cs_default_config('production', variant);
cfg.result_type = 'forward_screen';
data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
    cfg.analysis_window);
screenDir = fullfile(packageRoot, 'results', 'screen', variant);
blocksDir = fullfile(screenDir, 'blocks');
blockFiles = dir(fullfile(blocksDir, 'block_*.mat'));
if numel(blockFiles) ~= expectedBlocks
    error('cs:ScreenBlockCount', 'Expected %d blocks for %s but found %d.', ...
        expectedBlocks, variant, numel(blockFiles));
end

allTheta = zeros(0, numel(cfg.lower));
allMetrics = zeros(0, 15);
globalIndex = zeros(0, 1);
metricNames = {};
parameterNames = cfg.parameter_names;
requested = 0;
offset = 0;
for i = 1:numel(blockFiles)
    loaded = load(fullfile(blockFiles(i).folder, blockFiles(i).name), 'block');
    block = loaded.block;
    if ~strcmp(block.variant, variant)
        error('cs:WrongScreenVariant', 'Block variant mismatch: %s.', blockFiles(i).name);
    end
    requested = requested + block.n_requested;
    allTheta = [allTheta; block.theta]; %#ok<AGROW>
    allMetrics = [allMetrics; block.metrics]; %#ok<AGROW>
    globalIndex = [globalIndex; offset + block.sample_index]; %#ok<AGROW>
    offset = offset + block.n_requested;
    metricNames = block.metric_names;
end
if isempty(allTheta)
    error('cs:NoValidScreenRuns', 'No valid forward runs were produced for %s.', variant);
end

metricIndex = struct();
for j = 1:numel(metricNames)
    metricIndex.(matlab.lang.makeValidName(metricNames{j})) = j;
end
fluxShapePenalty = ((allMetrics(:, metricIndex.Corg_peak_1e18) - 13.5) ./ 2.0).^2 ...
    + ((allMetrics(:, metricIndex.Py_peak_1e18) - 6.7) ./ 1.5).^2 ...
    + ((allMetrics(:, metricIndex.O2_peak_1e18) - 26.5) ./ 3.0).^2;
allMetrics(:, end + 1) = fluxShapePenalty;
metricNames{end + 1} = 'flux_shape_penalty';
metricIndex.flux_shape_penalty = size(allMetrics, 2);
allMetrics(:, end + 1) = allMetrics(:, metricIndex.screen_score) ...
    + 0.60 .* fluxShapePenalty;
metricNames{end + 1} = 'four_panel_score';
metricIndex.four_panel_score = size(allMetrics, 2);
feasibleMask = allMetrics(:, metricIndex.fig2_feasible) == 1;
if any(feasibleMask)
    candidateIndex = find(feasibleMask);
else
    candidateIndex = (1:size(allTheta, 1))';
end
[~, localOrder] = sort(allMetrics(candidateIndex, metricIndex.four_panel_score), 'ascend');
rankedIndex = candidateIndex(localOrder);

% The manuscript envelope is a two-endmember sensitivity test. Keep every
% parameter fixed and change only delta13C_in to -8 and -5 permil. Select
% the first ranked case for which both endmembers obey the hard 1-3 mM
% sulfate constraint.
bestIndex = [];
bestOutMinus8 = struct();
bestOutMinus5 = struct();
for k = 1:numel(rankedIndex)
    candidateTheta = allTheta(rankedIndex(k), :);
    outMinus8 = cs_forward(candidateTheta, data, cfg, 'full', -8.0);
    outMinus5 = cs_forward(candidateTheta, data, cfg, 'full', -5.0);
    if outMinus8.ok && outMinus5.ok
        bestIndex = rankedIndex(k);
        bestOutMinus8 = outMinus8;
        bestOutMinus5 = outMinus5;
        break;
    end
end
if isempty(bestIndex)
    error('cs:NoEndpointValidScreenRun', [ ...
        'No ranked case keeps both delta13C_in=-8 and -5 permil ', ...
        'sensitivity trajectories within the 1-3 mM sulfate bounds.']);
end

remainingIndex = rankedIndex(rankedIndex ~= bestIndex);
topIndex = [bestIndex; remainingIndex(1:min(499, numel(remainingIndex)))];
bestTheta = allTheta(bestIndex, :);
bestMetrics = allMetrics(bestIndex, :);
bestOut = cs_forward(bestTheta, data, cfg, 'full');
if ~bestOut.ok
    error('cs:BestScreenForwardFailed', 'Selected screened forward run failed unexpectedly.');
end

bands = struct();
bands.age_ma = cfg.plot_grid;
bands.d34S_latent_q = endpoint_band(bestOutMinus8.d34S, ...
    bestOut.d34S, bestOutMinus5.d34S);
bands.S_mM_q = endpoint_band(bestOutMinus8.S_mM, ...
    bestOut.S_mM, bestOutMinus5.S_mM);
bands.Corg_q = endpoint_band(bestOutMinus8.Corg_18, ...
    bestOut.Corg_18, bestOutMinus5.Corg_18);
bands.Py_q = endpoint_band(bestOutMinus8.Py_18, ...
    bestOut.Py_18, bestOutMinus5.Py_18);
bands.O2_q = endpoint_band(bestOutMinus8.O2_18, ...
    bestOut.O2_18, bestOutMinus5.O2_18);

if ~isfolder(screenDir), mkdir(screenDir); end
allCandidateNames = [matlab.lang.makeValidName(parameterNames), ...
    matlab.lang.makeValidName(metricNames), {'Global_sample_index'}];
topTable = array2table([allTheta(topIndex, :), allMetrics(topIndex, :), ...
    globalIndex(topIndex)], 'VariableNames', allCandidateNames);
writetable(topTable, fullfile(screenDir, 'top_candidates.csv'));
bestTable = topTable(1, :);
writetable(bestTable, fullfile(screenDir, 'best_parameters.csv'));

timeseriesTable = table(cfg.plot_grid, ...
    bestOut.d34S, bestOutMinus8.d34S, bestOutMinus5.d34S, ...
    bands.d34S_latent_q(:, 1), bands.d34S_latent_q(:, 3), ...
    bestOut.S_mM, bestOutMinus8.S_mM, bestOutMinus5.S_mM, ...
    bands.S_mM_q(:, 1), bands.S_mM_q(:, 3), ...
    bestOut.Corg_18, bestOutMinus8.Corg_18, bestOutMinus5.Corg_18, ...
    bands.Corg_q(:, 1), bands.Corg_q(:, 3), ...
    bestOut.Py_18, bestOutMinus8.Py_18, bestOutMinus5.Py_18, ...
    bands.Py_q(:, 1), bands.Py_q(:, 3), ...
    bestOut.O2_18, bestOutMinus8.O2_18, bestOutMinus5.O2_18, ...
    bands.O2_q(:, 1), bands.O2_q(:, 3), ...
    'VariableNames', {'Age_Ma', ...
    'd34S_Best', 'd34S_d13Cin_minus8', 'd34S_d13Cin_minus5', ...
    'd34S_Envelope_Lower', 'd34S_Envelope_Upper', ...
    'Sulfate_mM_Best', 'Sulfate_mM_d13Cin_minus8', ...
    'Sulfate_mM_d13Cin_minus5', 'Sulfate_mM_Envelope_Lower', ...
    'Sulfate_mM_Envelope_Upper', ...
    'Corg_Best', 'Corg_d13Cin_minus8', 'Corg_d13Cin_minus5', ...
    'Corg_Envelope_Lower', 'Corg_Envelope_Upper', ...
    'Py_Best', 'Py_d13Cin_minus8', 'Py_d13Cin_minus5', ...
    'Py_Envelope_Lower', 'Py_Envelope_Upper', ...
    'O2_Best', 'O2_d13Cin_minus8', 'O2_d13Cin_minus5', ...
    'O2_Envelope_Lower', 'O2_Envelope_Upper'});
writetable(timeseriesTable, fullfile(screenDir, 'best_model_timeseries.csv'));

fitTable = data.obs;
fitTable.model_best = bestOut.obs_pred;
fitTable.residual = fitTable.d34S - fitTable.model_best;
writetable(fitTable, fullfile(screenDir, 'best_fit_to_TP.csv'));

summary = struct();
summary.workflow = 'forward_parameter_screen';
summary.variant = variant;
summary.blocks = expectedBlocks;
summary.requested_samples = requested;
summary.valid_samples = size(allTheta, 1);
summary.fig2_feasible_samples = nnz(feasibleMask);
summary.selection_used_fig2_feasible_pool = any(feasibleMask);
summary.best_theta = bestTheta;
summary.parameter_names = parameterNames;
summary.metric_names = metricNames;
summary.best_metrics = bestMetrics;
summary.best_TP_RMSE_permil = bestMetrics(metricIndex.TP_RMSE_permil);
summary.best_peak_d34S_permil = bestMetrics(metricIndex.event_peak_permil);
summary.best_peak_age_Ma = bestMetrics(metricIndex.event_peak_age_Ma);
summary.best_sulfate_min_mM = bestMetrics(metricIndex.S_min_mM);
summary.best_sulfate_max_mM = bestMetrics(metricIndex.S_max_mM);
summary.best_Corg_peak_1e18 = bestMetrics(metricIndex.Corg_peak_1e18);
summary.best_Py_peak_1e18 = bestMetrics(metricIndex.Py_peak_1e18);
summary.best_O2_peak_1e18 = bestMetrics(metricIndex.O2_peak_1e18);
summary.best_flux_shape_penalty = bestMetrics(metricIndex.flux_shape_penalty);
summary.best_four_panel_score = bestMetrics(metricIndex.four_panel_score);
summary.fig2_effect_pass = logical(bestMetrics(metricIndex.fig2_feasible));
summary.central_delta13C_in_effective_permil = bestOut.delta_in_effective;
summary.envelope_delta13C_in_permil = [-8.0, -5.0];
summary.envelope_definition = [ ...
    'Pointwise min/max of two fixed-parameter sensitivity runs; ', ...
    'not a confidence or posterior interval.'];
summary.sensitivity_minus8_sulfate_min_mM = min(bestOutMinus8.S_mM);
summary.sensitivity_minus8_sulfate_max_mM = max(bestOutMinus8.S_mM);
summary.sensitivity_minus5_sulfate_min_mM = min(bestOutMinus5.S_mM);
summary.sensitivity_minus5_sulfate_max_mM = max(bestOutMinus5.S_mM);
fid = fopen(fullfile(screenDir, 'screen_summary.json'), 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '%s\n', jsonencode(summary, 'PrettyPrint', true));
clear cleanup;

cs_make_fig2(data, cfg, bands, screenDir);
cs_make_screen_gif(data, cfg, allTheta, allMetrics, globalIndex, ...
    metricIndex, bands, bestMetrics, ...
    fullfile(screenDir, 'fig2_forward_screen.gif'));
save(fullfile(screenDir, 'screen_results.mat'), 'summary', 'bands', ...
    'bestTheta', 'bestOut', 'bestOutMinus8', 'bestOutMinus5', ...
    'topTable', 'allTheta', 'allMetrics', 'globalIndex', 'metricNames', ...
    'parameterNames', '-v7.3');
end

function band = endpoint_band(minus8, center, minus5)
%ENDPOINT_BAND Pointwise envelope with the selected central trajectory.
band = [min(minus8, minus5), center, max(minus8, minus5)];
end
