function comparison = cs_compare_screens(packageRoot)
%CS_COMPARE_SCREENS Compare best forward-screen cases from both variants.

variants = {'linear', 'nonlinear'};
records = cell(2, 1);
loadedResults = cell(2, 1);
for i = 1:2
    root = fullfile(packageRoot, 'results', 'screen', variants{i});
    records{i} = jsondecode(fileread(fullfile(root, 'screen_summary.json')));
    loadedResults{i} = load(fullfile(root, 'screen_results.mat'), ...
        'bestOut', 'bands');
end

Variant = string(variants(:));
Requested_samples = cellfun(@(x) x.requested_samples, records);
Valid_samples = cellfun(@(x) x.valid_samples, records);
Fig2_feasible_samples = cellfun(@(x) x.fig2_feasible_samples, records);
TP_RMSE_permil = cellfun(@(x) x.best_TP_RMSE_permil, records);
Peak_d34S_permil = cellfun(@(x) x.best_peak_d34S_permil, records);
Peak_age_Ma = cellfun(@(x) x.best_peak_age_Ma, records);
Sulfate_min_mM = cellfun(@(x) x.best_sulfate_min_mM, records);
Sulfate_max_mM = cellfun(@(x) x.best_sulfate_max_mM, records);
Fig2_effect_pass = cellfun(@(x) x.fig2_effect_pass, records);
comparison = table(Variant, Requested_samples, Valid_samples, ...
    Fig2_feasible_samples, TP_RMSE_permil, Peak_d34S_permil, Peak_age_Ma, ...
    Sulfate_min_mM, Sulfate_max_mM, Fig2_effect_pass);
writetable(comparison, fullfile(packageRoot, 'results', 'screen_comparison.csv'));

fig = figure('Visible', 'off', 'Color', 'w', 'Position', [50, 50, 1100, 720]);
ax = axes(fig); hold(ax, 'on');
colors = [0.00, 0.45, 0.70; 0.84, 0.37, 0.00];
for i = 1:2
    out = loadedResults{i}.bestOut;
    b = loadedResults{i}.bands;
    fill(ax, [b.age_ma; flipud(b.age_ma)], ...
        [b.d34S_latent_q(:, 1); flipud(b.d34S_latent_q(:, 3))], ...
        colors(i, :), 'FaceAlpha', 0.10, 'EdgeColor', 'none', ...
        'HandleVisibility', 'off');
    plot(ax, out.age_ma, out.d34S, '-', 'Color', colors(i, :), ...
        'LineWidth', 2.8, 'DisplayName', variants{i});
end
cfg = cs_default_config('production', 'linear');
data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
    cfg.analysis_window);
displayS = data.display.d34S;
tp = displayS.dataset == "TP";
djg = displayS.dataset == "DJG";
scatter(ax, displayS.age_ma(tp), displayS.d34S(tp), 38, 'o', ...
    'MarkerFaceColor', [0.45, 0.82, 0.66], 'MarkerEdgeColor', 'w', ...
    'DisplayName', 'TP (screen target)');
scatter(ax, displayS.age_ma(djg), displayS.d34S(djg), 38, 'd', ...
    'MarkerFaceColor', [0.83, 0.66, 0.79], 'MarkerEdgeColor', 'w', ...
    'DisplayName', 'DJG (display only)');
set(ax, 'XDir', 'reverse', 'Box', 'on', 'FontName', 'Arial', ...
    'FontSize', 12, 'TickDir', 'out');
xlim(ax, [cfg.plot_window(2), cfg.plot_window(1)]);
ylim(ax, [10, 40]);
xlabel(ax, 'Age (Ma)');
ylabel(ax, 'Seawater \delta^{34}S (‰)');
legend(ax, 'Location', 'northwest', 'Box', 'off');
exportgraphics(fig, fullfile(packageRoot, 'results', ...
    'screen_comparison.png'), 'Resolution', 300, 'BackgroundColor', 'white');
exportgraphics(fig, fullfile(packageRoot, 'results', ...
    'screen_comparison.pdf'), 'ContentType', 'vector', ...
    'BackgroundColor', 'white');
close(fig);
end
