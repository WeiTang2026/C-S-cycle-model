function out = cs_forward(theta, data, cfg, outputMode, deltaInOverride)
%CS_FORWARD Dynamic global carbon-sulfur box model.
%
% Physical time tau increases toward younger ages. The two integrated
% states are seawater sulfate concentration and its isotopic composition.

arguments
    theta (1,:) double
    data (1,1) struct
    cfg (1,1) struct
    outputMode (1,:) char {mustBeMember(outputMode, {'full', 'observations'})} = 'full'
    deltaInOverride (1,1) double = NaN
end

out = struct('ok', false, 'message', '', 'age_ma', cfg.plot_grid, ...
    'd34S', [], 'S_mM', [], 'obs_pred', [], 'Corg_18', [], ...
    'Py_18', [], 'Gyp_18', [], 'O2_18', [], 'carbon_residual_18', [], ...
    'DeltaS', NaN, 'DeltaC', NaN, 'eta', NaN, 'B_PYR0_18', NaN, ...
    'B_GYP0_18', NaN, 'delta_in_effective', NaN, ...
    'min_S_mM', NaN, 'max_S_mM', NaN);

if numel(theta) ~= numel(cfg.lower) || any(~isfinite(theta)) ...
        || any(theta < cfg.lower) || any(theta > cfg.upper)
    out.message = 'Parameter vector is non-finite or outside configured bounds.';
    return;
end

idx = cfg.index;
rho = theta(idx.rho);
S0_mM = theta(idx.S0);
y0 = theta(idx.y0);
DeltaC = theta(idx.DeltaC);
W_G = theta(idx.W_G);
W_C = theta(idx.W_C);
B_C = theta(idx.B_C);
W_PYR = theta(idx.W_PYR);
W_GYP = theta(idx.W_GYP);
if isempty(idx.eta)
    eta = 0.0;
else
    eta = theta(idx.eta);
end
DeltaS = rho .* DeltaC;

forcingAge = data.forcing.age_ma;
forcingValue = data.forcing.d13C;
forcingPP = pchip(forcingAge, forcingValue);
ageStart = cfg.plot_window(1);
tauEnd = ageStart - cfg.plot_window(2);
ageFromTau = @(tau) ageStart - tau;
deltaA = @(tau) ppval(forcingPP, ageFromTau(tau));
if isnan(deltaInOverride)
    deltaInEffective = (W_G .* cfg.delta_G + W_C .* cfg.delta_C) ...
        ./ (W_G + W_C);
else
    deltaInEffective = deltaInOverride;
end
BG = @(tau) (W_G + W_C) .* (deltaA(tau) - deltaInEffective) ./ DeltaC;

BG0 = BG(0);
if ~isfinite(BG0) || BG0 <= 0
    out.message = 'Initial organic-carbon burial is nonpositive.';
    return;
end
B_PYR0 = cfg.k0_pyr_to_corg .* BG0;
B_GYP0 = W_PYR + W_GYP - B_PYR0;
if ~isfinite(B_GYP0) || B_GYP0 <= 0
    out.message = 'Initial gypsum burial required for sulfur balance is nonpositive.';
    return;
end

try
    [tauSol, ySol] = ode45(@rhs, [0, tauEnd], [S0_mM; y0], cfg.ode_options);
catch ME
    out.message = sprintf('ODE failure: %s', ME.message);
    return;
end

if size(ySol, 2) ~= 2 || any(~isfinite(ySol), 'all')
    out.message = 'ODE solution is incomplete or non-finite.';
    return;
end
out.min_S_mM = min(ySol(:, 1));
out.max_S_mM = max(ySol(:, 1));
tol = 1e-6;
if out.min_S_mM < cfg.S_trajectory_bounds_mM(1) - tol ...
        || out.max_S_mM > cfg.S_trajectory_bounds_mM(2) + tol
    out.message = sprintf('Sulfate trajectory %.4f-%.4f mM violates 1-3 mM bounds.', ...
        out.min_S_mM, out.max_S_mM);
    return;
end

obsTau = ageStart - data.obs.age_ma;
out.obs_pred = interp1(tauSol, ySol(:, 2), obsTau, 'pchip');
if any(~isfinite(out.obs_pred))
    out.message = 'Observation predictions are non-finite.';
    return;
end

if strcmp(outputMode, 'full')
    gridTau = ageStart - cfg.plot_grid;
    out.d34S = interp1(tauSol, ySol(:, 2), gridTau, 'pchip');
    out.S_mM = interp1(tauSol, ySol(:, 1), gridTau, 'pchip');
    d13Cgrid = ppval(forcingPP, cfg.plot_grid);
    out.Corg_18 = (W_G + W_C) .* (d13Cgrid - deltaInEffective) ./ DeltaC;
    sulfateRatio = out.S_mM ./ S0_mM;
    bgRatio = out.Corg_18 ./ BG0;
    out.Py_18 = B_PYR0 .* sulfateRatio .* bgRatio .^ (1 + eta);
    out.Gyp_18 = B_GYP0 .* sulfateRatio;
    out.O2_18 = out.Corg_18 + 2 .* out.Py_18;
    out.carbon_residual_18 = W_G + W_C - out.Corg_18 - B_C;
    allFinite = all(isfinite(out.d34S)) && all(isfinite(out.S_mM)) ...
        && all(isfinite(out.Corg_18)) && all(isfinite(out.Py_18)) ...
        && all(isfinite(out.Gyp_18)) && all(isfinite(out.O2_18)) ...
        && all(isfinite(out.carbon_residual_18));
    if ~allFinite || any(out.Corg_18 <= 0) || any(out.Py_18 <= 0) ...
            || any(out.Gyp_18 <= 0)
        out.message = 'Full forward-model output is invalid.';
        return;
    end
end

out.DeltaS = DeltaS;
out.DeltaC = DeltaC;
out.eta = eta;
out.B_PYR0_18 = B_PYR0;
out.B_GYP0_18 = B_GYP0;
out.delta_in_effective = deltaInEffective;
out.ok = true;
out.message = 'OK';

    function dy = rhs(tau, y)
        S_mM = max(y(1), 0.05);
        bg = max(BG(tau), realmin);
        sulfateRatio = S_mM ./ S0_mM;
        bgRatio = bg ./ BG0;
        bPyr = B_PYR0 .* sulfateRatio .* bgRatio .^ (1 + eta);
        bGyp = B_GYP0 .* sulfateRatio;
        dSdt = ((W_PYR + W_GYP - bPyr - bGyp) .* 1e18) ...
            ./ cfg.mol_per_mM;
        S_mol = S_mM .* cfg.mol_per_mM;
        dDeltadt = (W_PYR .* 1e18 .* (cfg.delta_pyr - y(2)) ...
            + W_GYP .* 1e18 .* (cfg.delta_gyp - y(2)) ...
            + bPyr .* 1e18 .* DeltaS) ./ S_mol;
        dy = [dSdt; dDeltadt];
    end
end
