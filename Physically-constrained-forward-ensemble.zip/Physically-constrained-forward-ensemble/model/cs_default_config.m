function cfg = cs_default_config(mode, variant)
%CS_DEFAULT_CONFIG Configuration for the dual dynamic-sulfate inversion.

arguments
    mode (1,:) char {mustBeMember(mode, {'smoke', 'production'})} = 'production'
    variant (1,:) char {mustBeMember(variant, {'linear', 'nonlinear'})} = 'linear'
end

cfg.mode = mode;
cfg.variant = variant;
% Start at the oldest measured TP carbon-isotope datum, rather than the
% former 441.303 Ma display-series boundary. This also retains every TP
% sulfur-isotope observation in the calibration window.
cfg.record_start_age_ma = 441.524558823529;
cfg.analysis_window = [cfg.record_start_age_ma, 438.590];
cfg.plot_window = [cfg.record_start_age_ma, 438.000];
cfg.plot_grid = linspace(cfg.plot_window(1), cfg.plot_window(2), 500)';

% Flux parameters are stored in 10^18 mol Myr^-1, numerically equivalent
% to 10^12 mol yr^-1. B_C is intentionally prior-propagated: it appears in
% the carbon-reservoir mass balance diagnostic but not in the sulfur fit.
cfg.parameter_names = { ...
    'rho_DeltaS_over_DeltaC', ...
    'S0_sw_mM', ...
    'd34S_initial_permil', ...
    'DeltaC_permil', ...
    'W_G_1e18_mol_Myr', ...
    'W_C_1e18_mol_Myr', ...
    'B_C_1e18_mol_Myr_prior_propagated', ...
    'W_PYR_1e18_mol_Myr', ...
    'W_GYP_1e18_mol_Myr', ...
    'residual_scale_permil'};
cfg.lower = [0.30, 1.00, 15.0, 26.0, 4.0, 12.0, 12.0, 2.0, 1.0, 0.50];
cfg.upper = [1.80, 3.00, 27.0, 30.0, 8.0, 24.0, 24.0, 4.0, 2.0, 8.00];
cfg.reference_theta = [1.00, 2.50, 20.0, 27.0, 6.0, 18.0, 18.0, 3.0, 1.5, 2.50];
if strcmp(variant, 'nonlinear')
    cfg.parameter_names{end + 1} = 'eta_empirical';
    cfg.lower(end + 1) = -0.50;
    cfg.upper(end + 1) = 1.50;
    cfg.reference_theta(end + 1) = 0.30;
end

cfg.index = struct( ...
    'rho', 1, 'S0', 2, 'y0', 3, 'DeltaC', 4, ...
    'W_G', 5, 'W_C', 6, 'B_C', 7, 'W_PYR', 8, 'W_GYP', 9, ...
    'residual_scale', 10, 'eta', []);
if strcmp(variant, 'nonlinear')
    cfg.index.eta = 11;
end

cfg.delta_G = -27.0;   % permil, weathered organic-carbon reservoir
cfg.delta_C = 0.0;     % permil, weathered carbonate reservoir
cfg.delta_pyr = -10.0; % permil, weathered pyrite reservoir
cfg.delta_gyp = 30.0;  % permil, weathered gypsum reservoir
cfg.k0_pyr_to_corg = 0.5;
cfg.S_modern_mol = 42e18;
cfg.S_modern_mM = 28.8;
cfg.mol_per_mM = cfg.S_modern_mol / cfg.S_modern_mM;
cfg.S_trajectory_bounds_mM = [1.0, 3.0];
% Production forward screening fixes DeltaC at the user-requested value.
% The legacy MCMC transform bounds remain available but are not used by the
% current Latin-hypercube screening workflow.
cfg.forward_screen.fixed_DeltaC_permil = 27.0;

cfg.student_t_nu = 4.0;
cfg.ode_options = odeset('RelTol', 3e-6, 'AbsTol', [2e-7, 2e-6], ...
    'MaxStep', 0.025);

cfg.prior.y0_mean = 20.0;
cfg.prior.y0_sd = 3.0;
cfg.prior.DeltaC_mean = 28.0;
cfg.prior.DeltaC_sd = 1.0;
cfg.prior.rho_mean = 1.0;
cfg.prior.rho_sd = 0.35;
cfg.prior.log_residual_scale_median = log(2.5);
cfg.prior.log_residual_scale_sd = 0.60;
cfg.prior.eta_mean = 0.0;
cfg.prior.eta_sd = 0.75;

cfg.mcmc.target_accept = 0.24;
cfg.mcmc.adapt_start = 400;
cfg.mcmc.adapt_interval = 100;
if strcmp(variant, 'linear')
    cfg.mcmc.seed_base = 2026072300;
else
    cfg.mcmc.seed_base = 2026072400;
end
if strcmp(mode, 'smoke')
    cfg.mcmc.n_chains = 4;
    cfg.mcmc.nsimu = 900;
    cfg.mcmc.burnin = 300;
    cfg.mcmc.adapt_start = 100;
    cfg.mcmc.adapt_end = 300;
    cfg.mcmc.save_every = 25;
else
    cfg.mcmc.n_chains = 8;
    cfg.mcmc.nsimu = 100000;
    cfg.mcmc.burnin = 30000;
    cfg.mcmc.adapt_end = 30000;
    cfg.mcmc.save_every = 500;
end
cfg.mcmc.initial_z_scale = 0.18;
cfg.mcmc.min_accept = 0.08;
cfg.mcmc.max_accept = 0.60;
cfg.posterior.max_draws = 2000;
cfg.gif.n_frames = 36;
end
