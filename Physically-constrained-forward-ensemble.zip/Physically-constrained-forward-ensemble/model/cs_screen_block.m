function block = cs_screen_block(data, cfg, blockId, nSamples)
%CS_SCREEN_BLOCK Deterministic Latin-hypercube forward parameter screening.

arguments
    data (1,1) struct
    cfg (1,1) struct
    blockId (1,1) double {mustBeInteger, mustBePositive}
    nSamples (1,1) double {mustBeInteger, mustBePositive}
end

rng(cfg.mcmc.seed_base + 10000 + blockId, 'twister');
nParameters = numel(cfg.lower);
theta = repmat(cfg.reference_theta, nSamples, 1);
active = setdiff(1:nParameters, cfg.index.residual_scale);
for j = active
    strata = (randperm(nSamples)' - rand(nSamples, 1)) ./ nSamples;
    theta(:, j) = cfg.lower(j) + (cfg.upper(j) - cfg.lower(j)) .* strata;
end
theta(:, cfg.index.residual_scale) = 1.0;
theta(1, :) = cfg.reference_theta;
theta(1, cfg.index.residual_scale) = 1.0;
theta(:, cfg.index.DeltaC) = cfg.forward_screen.fixed_DeltaC_permil;

metricNames = {'TP_RMSE_permil', 'TP_MAE_permil', 'event_peak_permil', ...
    'event_peak_age_Ma', 'initial_d34S_permil', 'plateau_d34S_permil', ...
    'end_d34S_permil', 'S_min_mM', 'S_max_mM', 'shape_penalty', ...
    'screen_score', 'fig2_feasible', 'Corg_peak_1e18', ...
    'Py_peak_1e18', 'O2_peak_1e18'};
metrics = nan(nSamples, numel(metricNames));
valid = false(nSamples, 1);
eventWindow = cfg.plot_grid <= 438.90 & cfg.plot_grid >= 438.45;
plateauWindow = cfg.plot_grid <= 440.30 & cfg.plot_grid >= 439.20;

tStart = tic;
for i = 1:nSamples
    out = cs_forward(theta(i, :), data, cfg, 'full');
    if ~out.ok
        continue;
    end
    residual = data.obs.d34S - out.obs_pred;
    eventValues = out.d34S(eventWindow);
    eventAges = out.age_ma(eventWindow);
    [eventPeak, peakIndex] = max(eventValues);
    peakAge = eventAges(peakIndex);
    initialValue = out.d34S(1);
    plateauValue = mean(out.d34S(plateauWindow));
    endValue = out.d34S(end);
    shapePenalty = ((eventPeak - 32.5) ./ 1.5).^2 ...
        + ((peakAge - 438.65) ./ 0.12).^2 ...
        + ((initialValue - 20.0) ./ 2.0).^2 ...
        + ((plateauValue - 24.5) ./ 2.0).^2 ...
        + ((endValue - 22.0) ./ 2.0).^2;
    rmse = sqrt(mean(residual.^2));
    mae = mean(abs(residual));
    feasible = eventPeak >= 30.5 && eventPeak <= 34.5 ...
        && peakAge >= 438.50 && peakAge <= 438.82 ...
        && initialValue >= 17 && initialValue <= 23 ...
        && plateauValue >= 22 && plateauValue <= 28 ...
        && endValue >= 18 && endValue <= 26;
    screenScore = rmse + 0.75 .* shapePenalty;
    metrics(i, :) = [rmse, mae, eventPeak, peakAge, initialValue, ...
        plateauValue, endValue, min(out.S_mM), max(out.S_mM), ...
        shapePenalty, screenScore, double(feasible), max(out.Corg_18), ...
        max(out.Py_18), max(out.O2_18)];
    valid(i) = true;
end

block = struct();
block.variant = cfg.variant;
block.block_id = blockId;
block.seed = cfg.mcmc.seed_base + 10000 + blockId;
block.n_requested = nSamples;
block.n_valid = nnz(valid);
block.parameter_names = cfg.parameter_names;
block.metric_names = metricNames;
block.theta = theta(valid, :);
block.metrics = metrics(valid, :);
block.sample_index = find(valid);
block.runtime_seconds = toc(tStart);
end
