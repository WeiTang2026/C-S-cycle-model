function results = run_tests(packageRoot)
%RUN_TESTS Run the public forward-ensemble contract tests.

arguments
    packageRoot (1,:) char = fileparts(fileparts(mfilename('fullpath')))
end

addpath(fullfile(packageRoot, 'model'));
results = runtests(fullfile(packageRoot, 'tests'), ...
    'IncludeSubfolders', true);
assertSuccess(results);
end
