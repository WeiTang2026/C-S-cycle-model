#!/bin/bash -l
set -euo pipefail

PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PACKAGE_ROOT"

test -f cases.tsv
test -f model/cs_screen_block.m
if [[ -e summary/submitted_jobs.tsv ]]; then
  printf 'Refusing to overwrite summary/submitted_jobs.tsv\n' >&2
  exit 1
fi

export MATLAB_BIN="${MATLAB_BIN:-matlab}"
mkdir -p logs results/screen/linear/blocks \
  results/screen/nonlinear/blocks summary

array_submission="$(sbatch --parsable scripts/submit_forward_array.slurm)"
array_job="${array_submission%%;*}"
aggregate_submission="$(sbatch --parsable \
  --dependency="afterok:${array_job}" scripts/submit_aggregate.slurm)"
aggregate_job="${aggregate_submission%%;*}"

{
  printf 'role\tjob_id\n'
  printf 'forward_screen\t%s\n' "$array_job"
  printf 'aggregate\t%s\n' "$aggregate_job"
} > summary/submitted_jobs.tsv

printf 'ARRAY_JOB=%s\nAGGREGATE_JOB=%s\n' "$array_job" "$aggregate_job"
