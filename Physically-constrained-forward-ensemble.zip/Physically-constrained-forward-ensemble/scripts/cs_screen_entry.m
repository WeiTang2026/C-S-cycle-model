function cs_screen_entry(packageRoot, taskId)
%CS_SCREEN_ENTRY Slurm entry point for one forward-screen block.

arguments
    packageRoot (1,:) char
    taskId (1,1) double {mustBeInteger, mustBePositive}
end
addpath(fullfile(packageRoot, 'model'));
cases = readtable(fullfile(packageRoot, 'cases.tsv'), 'FileType', 'text', ...
    'Delimiter', '\t', 'TextType', 'string');
row = find(cases.task_id == taskId, 1);
if isempty(row)
    error('cs:BadTaskId', 'Task id %d is not present in cases.tsv.', taskId);
end
variant = char(cases.variant(row));
blockId = cases.block_id(row);
nSamples = cases.n_samples(row);
cfg = cs_default_config('production', variant);
data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
    cfg.analysis_window);

blocksDir = fullfile(packageRoot, 'results', 'screen', variant, 'blocks');
logsDir = fullfile(packageRoot, 'logs');
if ~isfolder(blocksDir), mkdir(blocksDir); end
if ~isfolder(logsDir), mkdir(logsDir); end
statusPath = fullfile(logsDir, sprintf('%s_block_%03d.status', variant, blockId));
write_status(statusPath, sprintf(['START variant=%s block=%d samples=%d ', ...
    'seed=%d time=%s'], variant, blockId, nSamples, ...
    cfg.mcmc.seed_base + 10000 + blockId, char(datetime('now'))));
block = cs_screen_block(data, cfg, blockId, nSamples);
save(fullfile(blocksDir, sprintf('block_%03d.mat', blockId)), ...
    'block', 'cfg', '-v7.3');
write_status(statusPath, sprintf(['COMPLETE variant=%s block=%d valid=%d/%d ', ...
    'runtime_seconds=%.3f time=%s'], variant, blockId, block.n_valid, ...
    block.n_requested, block.runtime_seconds, char(datetime('now'))));
end

function write_status(path, message)
fid = fopen(path, 'w');
if fid < 0, error('cs:StatusWriteFailed', 'Cannot write %s.', path); end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '%s\n', message);
end
