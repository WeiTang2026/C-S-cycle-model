function run_local_forward_screen(packageRoot, nSamples)
%RUN_LOCAL_FORWARD_SCREEN Small end-to-end forward-screen validation.

arguments
    packageRoot (1,:) char
    nSamples (1,1) double {mustBeInteger, mustBePositive} = 1500
end
addpath(fullfile(packageRoot, 'model'));
variants = {'linear', 'nonlinear'};
for i = 1:2
    variant = variants{i};
    cfg = cs_default_config('production', variant);
    data = cs_load_data(fullfile(packageRoot, 'data', 'cs_fig2_data.csv'), ...
        cfg.analysis_window);
    block = cs_screen_block(data, cfg, 1, nSamples);
    blocksDir = fullfile(packageRoot, 'results', 'screen', variant, 'blocks');
    if ~isfolder(blocksDir), mkdir(blocksDir); end
    save(fullfile(blocksDir, 'block_001.mat'), 'block', 'cfg', '-v7.3');
    summary = cs_aggregate_screen(packageRoot, variant, 1);
    fprintf(['SCREEN %s valid=%d/%d feasible=%d RMSE=%.3f ', ...
        'peak=%.3f sulfate=%.3f-%.3f\n'], variant, summary.valid_samples, ...
        summary.requested_samples, summary.fig2_feasible_samples, ...
        summary.best_TP_RMSE_permil, summary.best_peak_d34S_permil, ...
        summary.best_sulfate_min_mM, summary.best_sulfate_max_mM);
end
comparison = cs_compare_screens(packageRoot); %#ok<NASGU>
end
