function cs_aggregate_screen_entry(packageRoot, expectedBlocks)
%CS_AGGREGATE_SCREEN_ENTRY Aggregate both completed screen ensembles.

arguments
    packageRoot (1,:) char
    expectedBlocks (1,1) double {mustBeInteger, mustBePositive} = 48
end
addpath(fullfile(packageRoot, 'model'));
variants = {'linear', 'nonlinear'};
for i = 1:2
    summary = cs_aggregate_screen(packageRoot, variants{i}, expectedBlocks); %#ok<NASGU>
    fid = fopen(fullfile(packageRoot, 'summary', ...
        sprintf('screen_%s.status', variants{i})), 'w');
    cleanup = onCleanup(@() fclose(fid));
    fprintf(fid, 'COMPLETE variant=%s blocks=%d time=%s\n', ...
        variants{i}, expectedBlocks, char(datetime('now')));
    clear cleanup;
end
comparison = cs_compare_screens(packageRoot); %#ok<NASGU>
fid = fopen(fullfile(packageRoot, 'summary', 'aggregate.status'), 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, 'COMPLETE workflow=forward_screen time=%s\n', char(datetime('now')));
end
