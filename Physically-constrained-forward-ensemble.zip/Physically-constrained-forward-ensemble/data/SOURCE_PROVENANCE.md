# Data provenance

- Original workbook: `TP_section_source.xlsx` (not included in this public
  source-code snapshot)
- Sheet used: `Sheet2`
- SHA-256: `45f5552b39ffd131037200f770eac125d4eefb4ac2a77038013c06989278b0ca`
- Normalization script: `../scripts/build_normalized_data.m`

`cs_fig2_data.csv` is a long-form audit table. Every value records its source
sheet, original Excel column, and row. `use_in_likelihood` is the authoritative
inclusion flag before the explicit age window is applied.

The old B/C sequence contains 19 copies of values also present in the complete
Q/R DJG sequence. These are retained under `legacy_merged_DJG_copy` with an
inclusion flag of zero. This preserves provenance while preventing duplicate
likelihood contributions.

The supplied `Fig2_target.jpg` is a style/layout reference only. It is not a
numerical data source.
